<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bin extends Model
{
    use HasFactory;

    protected $fillable = [
        'bin_reference_number',
        'location',
        'supervisor_id',
        'bin_capacity',
        'status',
        'created_at',
        'updated_at'
    ];

    public function AirQualities()
    {
        return $this->hasMany(BinLevel::class);
    }

    public function BinLevels()
    {
        return $this->hasMany(BinAirquality::class);
    }
}
