
## About The API

This API is mainly suited for mobile applications
API endpoints are;
