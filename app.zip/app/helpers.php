<?php

/**
 * 
 * Function to generate reference number
 * 
 */
function gen_ref_number(int $id)
{
    if ($id < 10) {
        $id = '00' . $id;
    } else if ($id < 100) {
        $id = '0' . $id;
    }

    return 'SGMS-' . date('Ymd') . '-' . $id;
}
